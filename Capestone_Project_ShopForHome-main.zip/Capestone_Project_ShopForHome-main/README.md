# Capestone_Project_ShopForHome
This is a team project.The team consisted of 4 members.It is an online store for home decor items.
